import type { Config } from "tailwindcss";
import tailwindcssAnimate from "tailwindcss-animate";
import typography from "@tailwindcss/typography";

export default {
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	// Drive `dark:` variants from the `.dark` class on <html>, which
	// useTheme writes when the user picks a dark theme inside the app.
	// Without this, Tailwind defaults to `media` and `dark:` utilities
	// only fire from the OS `prefers-color-scheme` — which means the
	// in-app theme toggle has no effect on `dark:` rules.
	darkMode: 'class',
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		screens: {
			'sm': '640px',
			'sidebar': '900px',
			'md': '768px',
			'lg': '1024px',
			'xl': '1280px',
			'2xl': '1536px',
		},
		extend: {
			spacing: {
				'22': '5.5rem',
			},
			fontFamily: {
				sans: ['Inter Variable', 'Inter', 'system-ui', 'sans-serif'],
				display: ['Bebas Neue', 'Impact', 'Inter Variable', 'system-ui', 'sans-serif'],
				emoji: ['Apple Color Emoji', 'Segoe UI Emoji', 'Noto Color Emoji', 'Twemoji Mozilla', 'Android Emoji', 'EmojiSymbols', 'sans-serif'],
			},
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				success: {
					DEFAULT: 'hsl(var(--success))',
					foreground: 'hsl(var(--success-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)',
				xs: 'calc(var(--radius) - 8px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'pending-glow': {
					'0%, 100%': {
						boxShadow: '0 0 0 0 hsl(var(--primary) / 0)'
					},
					'50%': {
						boxShadow: '0 0 8px 2px hsl(var(--primary) / 0.15)'
					}
				},
			'badge-spotlight': {
				from: { transform: 'rotate(0deg)' },
				to: { transform: 'rotate(360deg)' }
			},
			'highlight-fade': {
				from: { backgroundColor: 'hsl(var(--primary) / 0.10)' },
				to: { backgroundColor: 'transparent' }
			},
			'collapsible-down': {
				from: { height: '0' },
				to: { height: 'var(--radix-collapsible-content-height)' }
			},
			'collapsible-up': {
				from: { height: 'var(--radix-collapsible-content-height)' },
				to: { height: '0' }
			},
			'accent-glow': {
				'0%, 100%': { opacity: '0.3' },
				'50%': { opacity: '0.6' }
			},
			'equaliser-bar': {
				// Vertical bounce for the bird-song play button's
				// inline equaliser. Bars share this keyframe and
				// stagger via animationDelay so the group reads as
				// an organic audio indicator.
				'0%, 100%': { transform: 'scaleY(0.35)' },
				'50%': { transform: 'scaleY(1)' }
			},
			'tutorial-tap': {
				// A soft "press" pulse for the demo cursor in the
				// verifier tutorial — shrinks briefly to read as a tap.
				'0%, 70%, 100%': { transform: 'scale(1)' },
				'80%': { transform: 'scale(0.78)' }
			},
			'logo-marquee': {
				// Endless horizontal scroll for the partner-logo rail.
				// The track renders its logo set an even number of
				// times, so shifting by half the track width loops
				// seamlessly.
				from: { transform: 'translateX(0)' },
				to: { transform: 'translateX(-50%)' }
			}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'pending-glow': 'pending-glow 2.5s ease-in-out infinite',
				'badge-spotlight': 'badge-spotlight 8s linear infinite',
				'highlight-fade': 'highlight-fade 1.5s ease-out forwards',
				'collapsible-down': 'collapsible-down 0.2s ease-out',
				'collapsible-up': 'collapsible-up 0.2s ease-out',
				'accent-glow': 'accent-glow 2s ease-in-out infinite',
				'equaliser-bar': 'equaliser-bar 0.9s ease-in-out infinite',
				'tutorial-tap': 'tutorial-tap 2.4s ease-in-out infinite',
				'logo-marquee': 'logo-marquee 40s linear infinite'
			}
		}
	},
	plugins: [tailwindcssAnimate, typography],
} satisfies Config;

====================================================================================================
